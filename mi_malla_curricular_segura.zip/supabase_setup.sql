-- Ejecuta este SQL en Supabase > SQL Editor.
-- Crea las tablas privadas para las materias y el archivo curricular.

create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  semester integer not null check (semester between 1 and 10),
  done boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.courses enable row level security;

create policy "Cada usuario ve sus materias"
on public.courses for select
to authenticated
using (auth.uid() = user_id);

create policy "Cada usuario agrega sus materias"
on public.courses for insert
to authenticated
with check (auth.uid() = user_id);

create policy "Cada usuario actualiza sus materias"
on public.courses for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "Cada usuario elimina sus materias"
on public.courses for delete
to authenticated
using (auth.uid() = user_id);


create table if not exists public.curriculum_files (
  user_id uuid primary key references auth.users(id) on delete cascade,
  storage_path text not null,
  file_name text not null,
  mime_type text not null,
  updated_at timestamptz not null default now()
);

alter table public.curriculum_files enable row level security;

create policy "Cada usuario consulta su archivo"
on public.curriculum_files for select
to authenticated
using (auth.uid() = user_id);

create policy "Cada usuario guarda su archivo"
on public.curriculum_files for insert
to authenticated
with check (auth.uid() = user_id);

create policy "Cada usuario actualiza su archivo"
on public.curriculum_files for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);


-- Crea en Storage un bucket llamado: mallas
-- Debe quedar como PRIVATE (no público).
-- Estas políticas limitan cada archivo a la carpeta con el ID de su dueño.

create policy "Usuario sube solo a su carpeta"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'mallas'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Usuario ve solo sus archivos"
on storage.objects for select
to authenticated
using (
  bucket_id = 'mallas'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Usuario actualiza solo sus archivos"
on storage.objects for update
to authenticated
using (
  bucket_id = 'mallas'
  and (storage.foldername(name))[1] = auth.uid()::text
)
with check (
  bucket_id = 'mallas'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Usuario elimina solo sus archivos"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'mallas'
  and (storage.foldername(name))[1] = auth.uid()::text
);
